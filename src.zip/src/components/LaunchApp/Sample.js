import React from 'react';

const Sample=()=>{
    return(
        <div style={{borderLeft= '6px solid green', height='500px'}}>

        </div>
    )
}
export default Sample